package com.security.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationOAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationOAuthApplication.class, args);
	}

}
