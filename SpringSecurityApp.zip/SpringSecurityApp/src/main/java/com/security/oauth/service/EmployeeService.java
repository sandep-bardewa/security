package com.security.oauth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.security.oauth.model.Employee;
import com.security.oauth.repo.EmployeeRepo;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepo  employeeRepo;
	
	
	public List<Employee> getEmployee() {
		return employeeRepo.findAll();
	}
	
	public void insert(Employee employee) {
		employeeRepo.save(employee);
	}

}
