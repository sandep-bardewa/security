package com.security.oauth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.security.oauth.model.Employee;
import com.security.oauth.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/welcome")
	public ModelAndView firstPage() {
		return new ModelAndView("welcome");
	}
	@GetMapping("/addNewEmployee")
	public ModelAndView uploadImage() {
		ModelAndView modelAndView = new ModelAndView();
		Employee user = new Employee();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("addNewEmployee");
		return modelAndView;
	}
	@RequestMapping(value = "/addNewEmployee", method = RequestMethod.POST)
	public ModelAndView processRequest(@ModelAttribute("emp") Employee emp) {
		employeeService.insert(emp);
		List<Employee> employees = employeeService.getEmployee();
		ModelAndView model = new ModelAndView("welcome");
		model.addObject("employees", employees);
		return model;
	}

    //show all employees saved in db
	@GetMapping("/showEmployees")
	public ModelAndView getEmployees() {
		List<Employee> employees = employeeService.getEmployee();
		ModelAndView model = new ModelAndView("showEmployees");
		model.addObject("employees", employees);
		return model;
	}
	@RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView login(Model model, String error, String logout) {
        if (error != null)
            model.addAttribute("errorMsg", "Your username and password are invalid.");

        if (logout != null)
            model.addAttribute("msg", "You have been logged out successfully.");

        return new ModelAndView("login");
	}
	

}
