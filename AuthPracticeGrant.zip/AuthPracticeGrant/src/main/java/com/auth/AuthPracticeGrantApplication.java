package com.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthPracticeGrantApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthPracticeGrantApplication.class, args);
	}

}
