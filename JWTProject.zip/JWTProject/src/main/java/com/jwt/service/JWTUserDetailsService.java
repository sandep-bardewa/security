package com.jwt.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.jwt.model.DAOUser;
import com.jwt.model.UserDTO;
import com.jwt.repo.UserDaoRepo;

@Service
public class JWTUserDetailsService implements UserDetailsService {

	@Autowired
	private UserDaoRepo userDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		/*
		 * if("javainuse".equals(username)) { return new User(username,
		 * "$2a$10$L8YJY1ogR4/BGQgqokvv6.j8EYiGom3B8FxauMeVKwgxIEQeWj/zC", new
		 * ArrayList<>()); }else {
		 * 
		 * throw new UsernameNotFoundException("User not found with username: " +
		 * username); }
		 */

		DAOUser user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);

		}
		return new User(user.getUsername(), user.getPassword(), new ArrayList<>());

	}

	public DAOUser save(UserDTO user) {
		DAOUser newUser = new DAOUser();
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		return userDao.save(newUser);
	}
}
